# Knative Security Policy

We're extremely grateful for security researchers and users that report vulnerabilities to the Knative Open Source Community. All reports are thoroughly investigated by a set of community volunteers.

To make a report, please email the private security@knative.team list with the security details and the details expected for all Knative bug reports.

See [Knative Security and Disclosure Information](https://knative.dev/docs/reference/security/) for more details.

# Contributing guidelines

Please refer to Knative's overall
[contribution guidelines](https://www.knative.dev/community/contributing/) to
find out how you can help.
